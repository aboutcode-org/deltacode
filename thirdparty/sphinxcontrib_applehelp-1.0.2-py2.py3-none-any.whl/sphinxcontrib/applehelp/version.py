"""
    sphinxcontrib.applehelp.version
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    :copyright: Copyright 2007-2019 by the Sphinx team, see README.
    :license: BSD, see LICENSE for details.
"""

__version__ = '1.0.2'
__version_info__ = tuple(map(int, __version__.split('.')))
