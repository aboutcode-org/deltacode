import re

BRACKETED = re.compile(r'(\([^\(\)]*\)|\[[^\[\]]*\])')
WS = ' '
